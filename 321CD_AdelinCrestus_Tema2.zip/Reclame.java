import java.io.IOException;

class Reclame {
    public static void main(String[] args) throws IOException, InterruptedException {
        Task2 task2 = new Task2();
        task2.solve();

    }
}